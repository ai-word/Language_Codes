# juniper

Juniper integration for Actix web

### server

```bash
cd examples/juniper
cargo run (or ``cargo watch -x run``)
# Started http server: 127.0.0.1:8080
```

### web client

[http://127.0.0.1:8080/graphiql](http://127.0.0.1:8080/graphiql)

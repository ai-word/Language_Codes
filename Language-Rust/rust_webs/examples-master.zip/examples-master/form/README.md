## Form example

```bash
cd form
cargo run
# Started http server: 127.0.0.1:8080
```


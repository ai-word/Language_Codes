# state

## Usage

### server

```bash
cd examples/state
cargo run
# Started http server: 127.0.0.1:8080
```

### web client

- [http://localhost:8080/](http://localhost:8080/)

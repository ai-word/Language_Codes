This example illustrates how to use nested resource registration through application-level configuration.  
The endpoints do nothing.


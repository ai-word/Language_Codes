This directory includes weather information obtained from NOAA for NYC Central Park: https://www.ncdc.noaa.gov/cdo-web/

# Setup Instructions

Set up a sqlite3 database by executing the setup_db.sh file: `bash sqlite_db.sh`

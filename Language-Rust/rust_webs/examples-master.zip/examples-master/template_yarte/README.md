# yarte

Example of composition with partials and `with-actix-web` feature

```bash
cargo test

cargo run
```
> open `localhost:8080`


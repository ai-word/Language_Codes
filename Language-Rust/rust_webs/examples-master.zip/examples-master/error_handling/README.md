This project illustrates custom error propagation through futures in actix-web

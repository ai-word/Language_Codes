# Actix Web CORS example

## start
1 - backend server
```bash
$ cd web-cors/backend
$ cargo run
```
2 - frontend server
```bash
$ cd web-cors/frontend
$ npm install
$ npm run serve
```
then open browser 'http://localhost:8080'

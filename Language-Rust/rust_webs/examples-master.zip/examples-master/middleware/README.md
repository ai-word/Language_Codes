## Middleware example

```bash
cd form
cargo run
# Started http server: 127.0.0.1:8080
```

Look in `src/main.rs` and comment the different middlewares in/out to see how
they function.


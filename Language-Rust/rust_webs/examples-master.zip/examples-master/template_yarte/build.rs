use yarte::recompile;

fn main() {
    recompile::when_changed();
}

table! {
    tasks (id) {
        id -> Int4,
        description -> Varchar,
        completed -> Bool,
    }
}

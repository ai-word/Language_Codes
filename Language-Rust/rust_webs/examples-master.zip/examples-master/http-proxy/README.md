## Http proxy example

To start proxy server:

```sh
cargo run --bin proxy
```

To start local backend server:

```sh
cargo run --bin proxy-example-server
```
